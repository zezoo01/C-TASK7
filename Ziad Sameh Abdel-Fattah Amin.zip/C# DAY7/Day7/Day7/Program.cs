﻿using static System.Net.Mime.MediaTypeNames;
using System.Reflection.Emit;
using System.Text;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Threading.Channels;
using System.Net.NetworkInformation;
using System.Reflection;
using System.Runtime.Intrinsics.X86;

namespace Day7
{
    class Day7
    {
        public static void Main(string[] args)
        {
            #region Problem 1
            ////Q1
            //Car C1 = new Car();
            //Console.WriteLine(C1);

            //Car C2 = new Car(7);
            //Console.WriteLine(C2);

            //Car C3 = new Car(9, "Nissan");
            //Console.WriteLine(C3);

            //Car C4 = new Car(3, "Kia", 90000);
            //Console.WriteLine(C4);
            ////In C#,the default parameterless constructor is provided by the compiler only if no constructors are explicitly defined.
            ////Defining a custom constructor suppresses it because the compiler assumes you're fully managing initialization.
            ////To have both, you must explicitly define the parameterless constructor.
            #endregion

            #region Problem 2
            ////--2
            //Calculator C = new Calculator();
            //int x = 5, y = 10, z = 7;
            //double a = 5.5, b = 7.5;
            ////Sum two integers
            //Console.WriteLine(C.Sum(x, y));
            ////Sum three integers
            //Console.WriteLine(C.Sum(x, y, z));
            ////Sum two double
            //Console.WriteLine(C.Sum(a, b));
            ////Method overloading improves code readability by allowing multiple methods with the same name but different parameters,
            ///making the code intuitive and easier to understand.
            ///It enhances reusability by enabling a single method name to handle various input types or scenarios,
            ///reducing redundancy and centralizing logic.
            #endregion

            #region Problem 3
            ////--3
            //Child C = new Child(5, 7, 1);
            //Console.WriteLine(C);
            ////The purpose of constructor chaining in inheritance is to:
            //// -Ensure proper initialization of base class members before derived class logic runs.
            //// -Reuse initialization logic and avoid code duplication.
            //// -Maintain consistency in how objects are initialized across the hierarchy.
            //// -Simplify constructor logic, especially in multi-level inheritance scenarios.
            //// -Enable flexibility by allowing the derived class to control how the base class is initialized. 
            #endregion

            #region Problem 4
            ////--4
            //Parent P = new Parent(2, 4);
            //Console.WriteLine(P.Product());
            //Child C = new Child(2, 4, 6);
            //Console.WriteLine(C.Product());
            ////override: override the base class method (base method must be virtual or abstract)
            ////new: hide the base class method 
            #endregion

            #region Problem 5
            ////--5
            //Parent P = new Parent(3, 7);
            //Console.WriteLine(P);
            //Child C = new Child(3, 7, 9);
            //Console.WriteLine(C);
            ////Why is ToString() often overridden in custom classes?
            //// -To change the behavior of the method based on bussines case 
            #endregion

            #region Problem 6
            ////--6
            //Rectangle R = new Rectangle();
            //Console.WriteLine(R.Area);
            //R.Draw();
            ////You cannot create an instance of an interface in C# because:
            //// -Interfaces do not provide any implementation, only the definition of members.
            //// -Interfaces are abstract by design, requiring a concrete class or struct to implement their members.
            //// -Interfaces exist to define contracts for polymorphism and dependency injection, not to act as standalone objects. 
            #endregion

            #region Problem 7
            ////--7
            //Circle C1 = new Circle();
            //C1.Draw();
            ////Cannot access PrintDetails() method
            ////C1.PrintDetails();
            //IShape C2 = new Circle();
            //C2.Draw();
            ////Can access PrintDetails() method
            //C2.PrintDetails();
            ////The benefits of default implementations in interfaces introduced in C# 8.0 include:
            //// -Backward Compatibility: Avoid breaking changes when extending interfaces.
            //// -Code Reusability: Share common logic across implementations.
            //// -Simplified API Evolution: Enhance interfaces without affecting existing implementations.
            //// -Reduced Need for Abstract Base Classes: Achieve shared functionality without base classes.
            //// -Enhanced Polymorphism: Provide default behaviors that can be reused or overridden. 
            #endregion

            #region Problem 8
            ////--8
            //IMovable C = new Car();
            //C.Move();
            ////Using an interface reference to access implementing class methods :
            //// -Enables Polymorphism: Interact generically with objects implementing the interface.
            //// -Decouples Code: Reduce dependency on concrete implementations for greater flexibility.
            //// -Simplifies Testing: Facilitate the use of mock implementations in testing.
            //// -Supports Multiple Implementations: Provide a common interface for diverse classes.
            //// -Promotes Extensibility: Add new functionality without modifying existing code.
            //// -Adheres to Design Principles: Aligns with SOLID principles, ensuring clean, modular design.
            //// -Improves Maintainability: Simplify updates and reduce the risk of cascading changes. 
            #endregion

            #region Problem 9
            ////--9
            //File F = new File();
            //F.Read();
            //F.Write();
            ////How does C# overcome the limitation of single inheritance with interfaces?
            //// By interface we can implement more than interface but we cannot do this with classes 
            #endregion

            #region Problem 10
            ////--10
            //Rect R = new Rect(7, 5);
            //R.Draw();
            //Console.WriteLine(R.CalculateArea());
            ////Virtual method:
            //// -Has a default implementation
            //// -Derived class can override it or not (optional)
            //// -Can be in any class

            ////Abstract method: 
            //// -No default implementation
            //// -Derived class must override it (mandatory)
            //// -Must be in abstract class 
            #endregion


        }
    }
}